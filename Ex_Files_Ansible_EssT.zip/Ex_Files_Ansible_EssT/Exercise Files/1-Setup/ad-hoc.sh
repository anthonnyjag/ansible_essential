#!/bin/bash
ansible -m ping -i ../inventory  web1
